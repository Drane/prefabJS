package be.tradelec.autopermit.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = BankAccount.class)
public class BankAccountDataOnDemand {
}
