package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = DivCache.class)
public class DivCacheIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
