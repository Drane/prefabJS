package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = TradLanguage.class)
public class TradLanguageIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
