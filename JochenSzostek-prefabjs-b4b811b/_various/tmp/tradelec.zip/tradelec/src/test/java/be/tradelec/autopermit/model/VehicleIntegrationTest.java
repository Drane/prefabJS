package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Vehicle.class)
public class VehicleIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
