package be.tradelec.autopermit.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Duration.class)
public class DurationDataOnDemand {
}
