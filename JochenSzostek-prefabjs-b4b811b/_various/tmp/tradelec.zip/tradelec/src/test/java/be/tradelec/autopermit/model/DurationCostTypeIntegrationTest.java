package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = DurationCostType.class)
public class DurationCostTypeIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
