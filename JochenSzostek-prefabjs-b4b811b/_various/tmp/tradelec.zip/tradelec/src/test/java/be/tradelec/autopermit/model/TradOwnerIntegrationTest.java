package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = TradOwner.class)
public class TradOwnerIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
