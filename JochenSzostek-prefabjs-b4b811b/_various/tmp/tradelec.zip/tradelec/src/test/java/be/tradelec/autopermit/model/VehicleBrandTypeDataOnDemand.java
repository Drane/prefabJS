package be.tradelec.autopermit.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = VehicleBrandType.class)
public class VehicleBrandTypeDataOnDemand {
}
