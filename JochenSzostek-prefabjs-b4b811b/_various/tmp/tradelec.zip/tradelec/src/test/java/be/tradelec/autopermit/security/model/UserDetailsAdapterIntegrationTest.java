package be.tradelec.autopermit.security.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = UserDetailsAdapter.class)
public class UserDetailsAdapterIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
