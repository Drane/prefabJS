package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = FamilyHasPerson.class)
public class FamilyHasPersonIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
