package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Payment.class)
public class PaymentIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
