package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Family.class)
public class FamilyIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
