package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Area.class)
public class AreaIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
