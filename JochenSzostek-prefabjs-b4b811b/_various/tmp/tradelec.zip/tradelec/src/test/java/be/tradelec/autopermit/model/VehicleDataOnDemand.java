package be.tradelec.autopermit.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Vehicle.class)
public class VehicleDataOnDemand {
}
