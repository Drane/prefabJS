package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Period.class)
public class PeriodIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
