package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = CompanyType.class)
public class CompanyTypeIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
