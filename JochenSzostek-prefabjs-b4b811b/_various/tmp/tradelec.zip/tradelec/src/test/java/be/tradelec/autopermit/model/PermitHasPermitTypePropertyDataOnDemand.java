package be.tradelec.autopermit.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = PermitHasPermitTypeProperty.class)
public class PermitHasPermitTypePropertyDataOnDemand {
}
