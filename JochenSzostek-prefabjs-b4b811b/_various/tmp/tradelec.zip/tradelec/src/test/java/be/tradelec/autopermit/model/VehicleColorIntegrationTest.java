package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = VehicleColor.class)
public class VehicleColorIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
