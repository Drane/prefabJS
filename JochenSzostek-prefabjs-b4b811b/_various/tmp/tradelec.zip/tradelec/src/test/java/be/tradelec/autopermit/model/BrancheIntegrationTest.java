package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Branche.class)
public class BrancheIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
