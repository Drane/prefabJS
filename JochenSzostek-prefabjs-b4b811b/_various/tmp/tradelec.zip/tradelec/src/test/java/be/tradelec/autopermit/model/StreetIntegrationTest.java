package be.tradelec.autopermit.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Street.class)
public class StreetIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
