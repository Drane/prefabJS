package be.tradelec.autopermit.service;

import be.tradelec.autopermit.model.Country;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.roo.addon.RooFlexScaffold;
import org.springframework.stereotype.Service;

@RooFlexScaffold(entity = Country.class)
@RemotingDestination
@Service
public class CountryService {
}
