package be.tradelec.autopermit.security.model;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import java.util.Set;
import be.tradelec.autopermit.security.model.AccountRole;
import java.util.HashSet;
import javax.persistence.ManyToMany;
import javax.persistence.CascadeType;
import javax.persistence.PrePersist;

import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;

@RooJavaBean
@RooToString
@RooEntity
public class Account {

    private String name;

    private String firstName;

    private String lastName;

    private String email;

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<AccountRole> accountRoleSet = new HashSet<AccountRole>();

    private Boolean enabled;

    private Boolean active;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date createDate;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date updateDate;

	@PrePersist
    private void prePersist(){
    if(createDate==null)
    	createDate = new Date();
    	updateDate = new Date();
    }
}
