package be.tradelec.autopermit.service;

import be.tradelec.autopermit.model.TradOwner;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.roo.addon.RooFlexScaffold;
import org.springframework.stereotype.Service;

@RooFlexScaffold(entity = TradOwner.class)
@RemotingDestination
@Service
public class TradOwnerService {
}
