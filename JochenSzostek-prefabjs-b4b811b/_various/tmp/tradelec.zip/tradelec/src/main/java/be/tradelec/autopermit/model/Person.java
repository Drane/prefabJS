package be.tradelec.autopermit.model;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import be.tradelec.autopermit.model.Nationality;
import javax.persistence.ManyToOne;
import java.util.Set;
import be.tradelec.autopermit.model.TradLanguage;
import java.util.HashSet;
import javax.persistence.ManyToMany;
import javax.persistence.CascadeType;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;
import javax.validation.constraints.Size;
import be.tradelec.autopermit.model.Address;
import be.tradelec.autopermit.model.PhoneNr;
import be.tradelec.autopermit.model.Vehicle;

@RooJavaBean
@RooToString
@RooEntity
public class Person {

    private String nationalNumber;

    private String firstName;

    private String name;

    private String initials;

    @ManyToOne
    private Nationality nationality;

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<TradLanguage> languageSet = new HashSet<TradLanguage>();

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date dateOfBirth;

    private String placeOfBirth;

    private Boolean isFemale;

    @Size(max = 4056)
    private String base64PhotoString;

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Address> addressSet = new HashSet<Address>();

    private String email;

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<PhoneNr> phoneNrSet = new HashSet<PhoneNr>();
    
    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Vehicle> vehicleSet = new HashSet<Vehicle>();

    private Boolean active;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date createDate;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date updateDate;
}
