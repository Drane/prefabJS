package be.tradelec.autopermit.service;

import be.tradelec.eid.EidData;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.roo.addon.RooFlexScaffold;
import org.springframework.stereotype.Service;

@RooFlexScaffold(entity = EidData.class)
@RemotingDestination
@Service
public class EidDataService {
}
