package be.tradelec.autopermit.service;

import be.tradelec.autopermit.model.PhoneNr;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.roo.addon.RooFlexScaffold;
import org.springframework.stereotype.Service;

@RooFlexScaffold(entity = PhoneNr.class)
@RemotingDestination
@Service
public class PhoneNrService {
}
