package be.tradelec.eid;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;
import javax.validation.constraints.Size;
import be.tradelec.eid.EidAddress;
import javax.persistence.OneToOne;

@RooJavaBean
@RooToString
@RooEntity
public class EidData {

    private String nationalNumber;

    private String name;

    private String firstName;

    private String firstName3;

    private String nationality;

    private String birthPlace;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date birthDate;

    private Boolean isFemale;

    @Size(max = 4056)
    private String base64PhotoString;

    @OneToOne(cascade = CascadeType.ALL)
    private EidAddress eidAddress;

    private Boolean active;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date createDate;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date updateDate;
    
    @PrePersist
    private void prePersist(){
    if(createDate==null)
    	createDate = new Date();
    	updateDate = new Date();
    }
}
