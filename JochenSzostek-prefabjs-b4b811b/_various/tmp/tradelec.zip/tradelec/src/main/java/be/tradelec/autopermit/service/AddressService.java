package be.tradelec.autopermit.service;

import be.tradelec.autopermit.model.Address;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.roo.addon.RooFlexScaffold;
import org.springframework.stereotype.Service;

@RooFlexScaffold(entity = Address.class)
@RemotingDestination
@Service
public class AddressService {
}
