package be.tradelec.autopermit.service;

import be.tradelec.autopermit.model.CompanyType;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.roo.addon.RooFlexScaffold;
import org.springframework.stereotype.Service;

@RooFlexScaffold(entity = CompanyType.class)
@RemotingDestination
@Service
public class CompanyTypeService {
}
