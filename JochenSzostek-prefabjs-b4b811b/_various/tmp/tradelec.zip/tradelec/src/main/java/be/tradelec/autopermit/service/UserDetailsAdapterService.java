package be.tradelec.autopermit.service;

import be.tradelec.autopermit.security.model.UserDetailsAdapter;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.roo.addon.RooFlexScaffold;
import org.springframework.stereotype.Service;

@RooFlexScaffold(entity = UserDetailsAdapter.class)
@RemotingDestination
@Service
public class UserDetailsAdapterService {
}
