package be.tradelec.autopermit.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

import be.tradelec.autopermit.model.Area;
import be.tradelec.autopermit.model.City;
import be.tradelec.autopermit.model.Country;
import be.tradelec.autopermit.model.Nationality;
import be.tradelec.autopermit.model.Period;
import be.tradelec.autopermit.model.PermitType;
import be.tradelec.autopermit.model.RegionProvince;
import be.tradelec.autopermit.model.Street;
import be.tradelec.autopermit.model.TradLanguage;
import be.tradelec.autopermit.model.Vehicle;
import be.tradelec.autopermit.model.VehicleBrand;
import be.tradelec.autopermit.model.VehicleBrandType;
import be.tradelec.autopermit.model.VehicleColor;
import be.tradelec.eid.EidData;
import be.tradelec.autopermit.service.EidDataService;
import be.tradelec.autopermit.service.NationalityService;
import be.tradelec.autopermit.service.RegionProvinceService;
import be.tradelec.autopermit.service.TradLanguageService;

@RemotingDestination
@Service
public class ServiceLayer {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	/*
	 * SERVICES
	 */
	@Autowired
	EidDataService eidDataService;
	@Autowired
	NationalityService nationalityService;
	@Autowired
	TradLanguageService tradLanguageService;
	@Autowired
	CountryService countryService;
	@Autowired
	RegionProvinceService regionProvinceService;
	@Autowired
	CityService cityService;
	@Autowired
	StreetService streetService;
	@Autowired
	VehicleService vehicleService;
	@Autowired
	VehicleBrandService vehicleBrandService;
	@Autowired
	VehicleBrandTypeService vehicleBrandTypeService;
	@Autowired
	VehicleColorService vehicleColorService;
	@Autowired
	AreaService areaService;
	@Autowired
	PeriodService periodService;
	@Autowired
	PermitTypeService permitTypeService;
	
	/*
	 * FINDALL METHODS
	 */

	
	public String getServerStatus(){
		return "all systems OK";
	}
	
//	public Street findStreetByCountryRegionProvinceCityStrings(String countryString, String regionProvinceString, String CityString){
//		
//		Country.findCountry(id)
//		
//		return null;
//		
//	}
	
	public List<EidData> findAllEidDatas(){
		List<EidData> result = eidDataService.list(); 
		log.debug("findAllEidDatas result ({}): {}", result.size(), result);
		return result;
	}
	public EidData persistEidData(EidData eidData){
		log.debug("persistEidData eidData:"+eidData);
		return eidDataService.create(eidData);
	}
	
	public List<Nationality> findAllNationalities(){
		List<Nationality> result = nationalityService.list(); 
		log.debug("findAllNationalities result ({}): {}", result.size(), result);
		return result;
	}
	
	public List<TradLanguage> findAllTradLanguages(){
		List<TradLanguage> result = tradLanguageService.list(); 
		log.debug("findAllTradLanguages result ({}): {}", result.size(), result);
		return result;
	}
	
	public List<Country> findAllCountries(){
		List<Country> result = countryService.list(); 
		log.debug("findAllCountries result ({}): {}", result.size(), result);
		return result;
	}
	
	public List<RegionProvince> findAllRegionProvinces(){
		List<RegionProvince> result = regionProvinceService.list(); 
		log.debug("findAllRegionProvinces result ({}): {}", result.size(), result);
		return result;
	}
	
	public List<City> findAllCities(){
		List<City> result = cityService.list(); 
		log.debug("findAllCities result ({}): {}", result.size(), result);
		return result;
	}
	
	public List<Street> findAllStreets(){
		List<Street> result = streetService.list(); 
		log.debug("findAllStreets result ({}): {}", result.size(), result);
		return result;
	}
	
	public List<RegionProvince> findRegionProvincesByCountry(Country country){
		List<RegionProvince> result =  RegionProvince.findRegionProvincesByCountry(country).getResultList();
		log.debug("findRegionProvincesByCountry result ({}): {}", result.size(), result);
		return result;
	}
	
	public List<City> findCitiesByRegionProvince(RegionProvince regionProvince){
		List<City>result =  City.findCitysByRegionProvince(regionProvince).getResultList();
		log.debug("findCitiesByRegionProvince result ({}): {}", result.size(), result);
		return result;
	}
	
	public List<Street> findStreetsByCity(City city){
		List<Street>result =  Street.findStreetsByCity(city).getResultList();
		log.debug("findCitiesByRegionProvince result ({}): {}", result.size(), result);
		return result;
	}
	
	/*
	 * AREA METHODS
	 */
	public List<Area> findAllAreas(){
		List<Area> result = areaService.list(); 
		log.debug("findAllAreas result ({}): {}", result.size(), result);
		return result;
	}
	/*
	 * VEHICLE METHODS
	 */
	public List<Vehicle> findAllVehicles(){
		List<Vehicle> result = vehicleService.list(); 
		log.debug("findAllVehicles result ({}): {}", result.size(), result);
		return result;
	}
	public List<VehicleColor> findAllVehicleColors(){
		List<VehicleColor> result = vehicleColorService.list(); 
		log.debug("findAllVehicleColors result ({}): {}", result.size(), result);
		return result;
	}
	public List<VehicleBrand> findAllVehicleBrands(){
		List<VehicleBrand> result = vehicleBrandService.list(); 
		log.debug("findAllVehicleBrands result ({}): {}", result.size(), result);
		return result;
	}
	public List<VehicleBrandType> findAllVehicleBrandType(){
		List<VehicleBrandType> result = vehicleBrandTypeService.list(); 
		log.debug("findAllVehicleBrandType result ({}): {}", result.size(), result);
		return result;
	}
	
	public List<VehicleBrandType> findVehicleBrandTypesByVehicleBrand(VehicleBrand vehicleBrand){
		List<VehicleBrandType> result = VehicleBrandType.findVehicleBrandTypesByVehicleBrand(vehicleBrand).getResultList();
		log.debug("findVehicleBrandTypesByVehicleBrand result ({}): {}", result.size(), result);
		return result;
	}
//	public List<VehicleBrandType> findAllVehicleBrandType(){
//		List<VehicleBrandType> result = vehicleBrandTypeService.list(); 
//		log.debug("findAllVehicleBrandType result ({}): {}", result.size(), result);
//		return result;
//	}
	
	/*
	 * PERIOD METHODS
	 */
	public List<Period> findAllPeriods(){
		List<Period> result = periodService.list(); 
		log.debug("findAllPeriods result ({}): {}", result.size(), result);
		return result;
	}
	
	/*
	 * PERMITTYPE METHODS
	 */
	public List<PermitType> findAllPermitTypes(){
		List<PermitType> result = permitTypeService.list(); 
		log.debug("findAllPermitTypes result ({}): {}", result.size(), result);
		return result;
	}
}
