package be.tradelec.autopermit.service;

import be.tradelec.autopermit.model.Street;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.roo.addon.RooFlexScaffold;
import org.springframework.stereotype.Service;

@RooFlexScaffold(entity = Street.class)
@RemotingDestination
@Service
public class StreetService {
}
