package be.tradelec.autopermit.model;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import be.tradelec.autopermit.model.TradOwner;
import javax.persistence.ManyToOne;
import be.tradelec.autopermit.model.Holder;
import be.tradelec.autopermit.model.PermitType;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;

@RooJavaBean
@RooToString
@RooEntity
public class Permit {

    @ManyToOne
    private TradOwner owner;

    @ManyToOne
    private Holder holder;

    @ManyToOne
    private PermitType type;

    private Boolean active;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date createDate;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date updateDate;
}
