package be.tradelec.log;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;

@RooJavaBean
@RooToString
@RooEntity
public class Log {
	
    public Log() {
		super();
	}

	public Log(String logLevel, String logMessage) {
		super();
		this.logLevel = logLevel;
		this.logMessage = logMessage;
	}

    private String logLevel;

    private String logMessage;

    private Boolean active;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date createDate;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date updateDate;
}
