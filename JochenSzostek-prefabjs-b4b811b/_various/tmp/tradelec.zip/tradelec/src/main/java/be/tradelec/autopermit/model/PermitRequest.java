package be.tradelec.autopermit.model;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import be.tradelec.eid.EidData;
import javax.persistence.ManyToOne;
import be.tradelec.autopermit.model.PermitType;
import be.tradelec.autopermit.model.Area;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;
import be.tradelec.autopermit.model.Period;

@RooJavaBean
@RooToString
@RooEntity
public class PermitRequest {

    @ManyToOne
    private EidData eidIdentity;

    private String licensePlate;

    private String telephoneNr;

    private String email;

    @ManyToOne
    private PermitType permitType;

    @ManyToOne
    private Area area;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date startDate;

    private int xfactor;

    @ManyToOne
    private Period period;

    private Boolean active;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date createDate;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date updateDate;
}
