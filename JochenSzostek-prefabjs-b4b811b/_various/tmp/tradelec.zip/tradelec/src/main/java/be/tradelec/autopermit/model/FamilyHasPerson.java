package be.tradelec.autopermit.model;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import be.tradelec.autopermit.model.Family;
import javax.persistence.ManyToOne;
import be.tradelec.autopermit.model.Person;
import be.tradelec.autopermit.model.FamilyRelation;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;

@RooJavaBean
@RooToString
@RooEntity
public class FamilyHasPerson {

    @ManyToOne
    private Family family;

    @ManyToOne
    private Person person;

    @ManyToOne
    private FamilyRelation familyRelation;

    private Boolean active;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date createDate;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date updateDate;
}
