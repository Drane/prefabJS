package be.tradelec.autopermit.model;

import org.springframework.roo.addon.entity.RooEntity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import java.util.Set;
import be.tradelec.autopermit.model.TradLanguage;
import java.util.HashSet;
import javax.persistence.ManyToMany;
import javax.persistence.CascadeType;
import be.tradelec.autopermit.model.Address;
import be.tradelec.autopermit.model.PhoneNr;
import be.tradelec.autopermit.model.Branche;
import javax.persistence.ManyToOne;
import be.tradelec.autopermit.model.CompanyType;
import javax.validation.constraints.NotNull;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;

@RooJavaBean
@RooToString
@RooEntity
public class Company {

    private String name;

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<TradLanguage> languagueSet = new HashSet<TradLanguage>();

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Address> addressSet = new HashSet<Address>();

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<PhoneNr> phoneNrSet = new HashSet<PhoneNr>();

    @ManyToOne
    private Branche branche;

    @NotNull
    @ManyToOne
    private CompanyType type;

    private Boolean active;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date createDate;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "S-")
    private Date updateDate;
}
