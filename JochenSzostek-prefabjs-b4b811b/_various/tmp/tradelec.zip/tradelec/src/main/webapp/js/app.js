/*
define(['dep1', 'dep2', 'require'], function (dep1, dep2, require) { 
     var dep3 = require('dep3'); 
     var dep4ID = 'dep4'; 
     require([dep4ID], function (dep4) { 
         // do stuff 
     }); 
     require(['dep5'], function (dep5) { 
         // do stuff 
     }); 
     var dep6ID = 'dep6'; 
     require(dep6ID); 
}); 

dep1, dep2, dep3 will ALL be loaded BEFORE factory is executed 
dep4 will be loaded as a result of executing factory 
dep1, dep2, dep3 AND dep5 will all be considered dependencies when doing 
a build 
dep4 will not be found as a dependency during a build 
dep6 - this pattern should never be used 
 */

require(["order!jquery","order!ps-log4js-console-ext","order!ember-0.9.7.1"], function($) {
	//"order!ember-resource","order!ember-rest"
	//"order!ps-log4js-console-ext",

	/*
	 * LOG4JAVASCRIPT stuff
	 */
	
	//require('ps-log4js-console-ext');

	/*
	 * EMBER stuff
	 */

	//require('ember-0.9.7.1');
	
	function isGlobal(reference){
		if(typeof window[reference]==='undefined'){
			console.error(reference+" global is not loaded!!");
			return false;
		}else{
			console.debug(reference+" global is loaded.");
			return true;
		}
	}
	
	isGlobal("Ember");

	PsApp = Ember.Application.create();

	/*
	 * PsApp.MainView = Em.View.extend({ templateName: 'main_view' });
	 */

	PsApp.logController = Ember.Object.create({
		
		message : 'test from html',
		
		log : function(message) {
			console.log(this.message);
		},
		trace : function() {
			console.trace();
		},
		debug : function(message) {
			console.debug(this.message);
		},
		info : function() {
			console.info(this.message);
		},
		warn : function() {
			console.warn(this.message);
		},
		error : function() {
			console.error(this.message);
		},
		fatal : function() {
			console.fatal(this.message);
		},
		group : function() {
			console.group(this.message);
		},
		groupEnd : function() {
			console.groupEnd();
		},
		assert : function() {
			console.assert(0==1);
		}
	});
	
	
	PsApp.MainView = Em.View.extend({
		attributes: {
			id : 'replacedByApplet',
			codebase : '.',
			code : 'MainApplet.class',
//			archive : 'sbeidapplet.jar,lib/log4j-1.2.16.jar,lib/logback-core-1.0.0.jar,lib/slf4j-api-1.6.4.jar,lib/slf4j-log4j12-1.6.4.jar,lib/jEidlib_1.1.jar,lib/forms-1.2.1.jar',
//			archive : 'beidapplet.jar,lib/guava-11.0.2.jar,lib/jsr305-1.3.9.jar,lib/logback-core-1.0.0.jar,lib/logback-classic-1.0.0.jar,lib/slf4j-api-1.6.4.jar,lib/plugin.jar,lib/slf4j-api-1.6.4.jar',
			archive : 'applet/applet.jar',
			width : 710,
			height : 540
		},
		parameters: {
				fontSize : 16
		},
		mouseDown : function() {
/*
			console.group("demo");
			console.log('MainView mouseDown log');
			console.trace('MainView mouseDown trace');
			console.debug('MainView mouseDown debug');
			console.info('MainView mouseDown info');
			console.warn('MainView mouseDown warn');
			console.error('MainView mouseDown error');
			console.groupEnd();
*/
			require('deployJava');
			deployJava.writeAppletTag(this.attributes, this.parameters);
		},
		classNameBindings : [ 'isReplacedByApplet:replacedByApplet' ],
		isReplacedByApplet : true
	});
	
	PsApp.Eid = Ember.Resource.extend({
	  resourceUrl:        '/eid',
	  resourceName:       'eid',
	  resourceProperties: ['eid_data', 'eid_address'],

	  validate: function() {
	    if (this.get('eid_data') === undefined || this.get('eid_data') === '' ||
	        this.get('eid_address') === undefined  || this.get('eid_address') === '') {
	      return 'Eid reads require a data and a address part.';
	    }
	  },

	  fullEid: Ember.computed(function() {
	    return this.get('eid_data') + ' ' + this.get('eid_address');
	  }).property('eid_data', 'eid_address')
	});
	
	
	
	
/*	function setEid(iDData, iDAddress, iDPhoto){
		console.debug(iDData);
		console.debug(iDAddress);
		console.debug(iDPhoto);
	}*/
/*	PsApp.eid = Ember.Object.create({
		
	});*/

});