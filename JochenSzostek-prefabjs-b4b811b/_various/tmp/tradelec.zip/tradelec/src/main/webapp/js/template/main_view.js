{{#view Em.Button classBinding="isActive" target="LogApp.logController" action="onLog"}}
  log
{{/view}}
